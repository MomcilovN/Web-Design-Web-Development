﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace ProdajaAutomobila1.Data
{
    public class ApplicationUser: IdentityUser
    {
          
        [Required]
        public string Ime { get; set; }
        [Required]
        public string Prezime { get; set; }
    }
}

