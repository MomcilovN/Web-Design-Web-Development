﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ProdajaAutomobila1.Models
{
    public class Automobil
    {
       
           public int AutomobilId { get; set; }
            [Required]
            public string Marka { get; set; }

            [Required]
            public string Model { get; set; }
            [Required]
            [MaxLength(4)]
            public int Godiste { get; set; }
            [Required]
            public int ZapreminaMotora { get; set; }
            [Required]
            public string Snaga { get; set; }
            [Required]
            public string Gorivo { get; set; }
            [Required]
            public string Karoserija { get; set; }


            // [Required]
            public string Fotografija { get; set; }
            public string Opis { get; set; }
            [Required]
           
            public decimal Cena { get; set; }
            [Required]
            public string Kontakt { get; set; }
        public static List<Automobil> PrikaziAutomobile()
        {
            ProdajaAutomobilaContext db = new ProdajaAutomobilaContext();
            List<Automobil> automobili = db.Automobili.ToList();
            return automobili;
        }
        public static void DodajAutomobil(Automobil automobil)
        {
            ProdajaAutomobilaContext db = new ProdajaAutomobilaContext();
            db.Automobili.Add(automobil);
            db.SaveChanges();
        }


    }
}
