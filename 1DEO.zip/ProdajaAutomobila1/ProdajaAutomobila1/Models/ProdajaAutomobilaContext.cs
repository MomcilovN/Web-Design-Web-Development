﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProdajaAutomobila1.Models
{
    public class ProdajaAutomobilaContext : DbContext
    {
        public ProdajaAutomobilaContext(DbContextOptions<ProdajaAutomobilaContext> opcije) : base(opcije)
        {
        }
        public DbSet<Automobil> Automobili { get; set; }
        public ProdajaAutomobilaContext()
        { }
    }
}
