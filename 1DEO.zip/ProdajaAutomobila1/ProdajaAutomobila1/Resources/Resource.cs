﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProdajaAutomobila1.Resources
{
    public class Resource
    {
    }
}
