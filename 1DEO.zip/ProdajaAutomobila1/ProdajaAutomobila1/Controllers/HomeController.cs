﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ProdajaAutomobila1.Models;
using Microsoft.AspNetCore.Identity;
using ProdajaAutomobila1.Data;

namespace ProdajaAutomobila1.Controllers
{
    public class HomeController : Controller
    {
        //private readonly ILogger<HomeController> _logger;

        private readonly UserManager<ApplicationUser> userManager;
        private readonly RoleManager<IdentityRole> roleManager;

        public HomeController(UserManager<ApplicationUser> _userManager,
        RoleManager<IdentityRole> _roleManager)
        {
            userManager = _userManager;
            roleManager = _roleManager;
        }
        //private async Task<int> KreirajRolu(string rola)
        //{
        //    bool rolaPostoji = await roleManager.RoleExistsAsync(rola); if (rolaPostoji) { return 0; }
        //    else
        //    {
        //        IdentityRole rolaAdmin = new IdentityRole(rola); var rezultat = await roleManager.CreateAsync(rolaAdmin);

        //        if (rezultat.Succeeded) { return 1; } else { return -1; }
        //    }
        //}
        //private async Task<ApplicationUser> KreirajAdministratora()
        //{
        //    ApplicationUser admin = await userManager.FindByNameAsync("Admin");

        //    if (admin == null)
        //    {         //Novi korisnik        
        //        admin = new ApplicationUser         {         
        //            UserName = "admin",          
        //            Ime = "Marko",             
        //            Prezime = "Markovic"         }; 

        //        string lozinka = "Marko123.";

        //        var rezultat = await userManager.CreateAsync(admin, lozinka); if (rezultat.Succeeded) 
        //        { return admin; } 
        //        else { return null; }
        //    }
        //    else
        //    {         //admin vec postoji        
        //        return admin;
        //    }
        //}
        //public async Task<IActionResult> AdminSistema()
        //{
        //    int rolaPostoji = await KreirajRolu("admin");
        //    if (rolaPostoji == -1)
        //    {
        //        ViewBag.Poruka = "Greska pri kreiranju role";
        //    }
        //    ApplicationUser user = await KreirajAdministratora();
        //    var rezultat = await userManager.AddToRoleAsync(user, "admin");
        //    if (rezultat.Succeeded)
        //    {
        //        ViewBag.Poruka = "Dodata rola";
        //    }
        //    else
        //    {
        //        ViewBag.Poruka = "Nije uspesno dodata rola";
        //    }
        //    return View();
        //}

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
