﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ProdajaAutomobila1.Migrations
{
    public partial class Druga : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Automobili",
                columns: table => new
                {
                    AutomobilId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Marka = table.Column<string>(nullable: false),
                    Model = table.Column<string>(nullable: false),
                    Godiste = table.Column<int>(maxLength: 4, nullable: false),
                    ZapreminaMotora = table.Column<int>(nullable: false),
                    Snaga = table.Column<string>(nullable: false),
                    Gorivo = table.Column<string>(nullable: false),
                    Karoserija = table.Column<string>(nullable: false),
                    Fotografija = table.Column<string>(nullable: true),
                    Opis = table.Column<string>(nullable: true),
                    Cena = table.Column<decimal>(nullable: false),
                    Kontakt = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Automobili", x => x.AutomobilId);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Automobili");
        }
    }
}
